﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Arenda.Forms
{
    public partial class TorgovieCentriForm : Form
    {
        public TorgovieCentriForm()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            Clases.TcClass.TcNumber(dataGridView1.CurrentRow.Cells[0].Value.ToString());
                dataGridView2.DataSource = Clases.TcClass.dtTcN;
        }

       
        private void TorgovieCentriForm_Load(object sender, EventArgs e)
        {
            Clases.TcClass.TcList();
            dataGridView1.DataSource = Clases.TcClass.dtTc;

            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Forms.AddTc AddTc = new Forms.AddTc();
            AddTc.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Forms.Add.AddPomesh AddPomesh = new Forms.Add.AddPomesh();
            AddPomesh.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Вы уверены что хотите удалить этот торговый центер?", "Удаление записи", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if (result == DialogResult.Yes)
            {
                if (Clases.TcClass.DeleteTc(dataGridView1.CurrentRow.Cells[0].Value.ToString()) == true)
                {
                    Clases.TcClass.TcList();
                    MessageBox.Show("Запись удалена!");

                }
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Вы уверены что хотите удалить это помещение?", "Удаление записи", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if (result == DialogResult.Yes)
            {
                if (Clases.TcClass.DeletePomesh(dataGridView1.CurrentRow.Cells[0].Value.ToString()) == true)
                {
                    Clases.TcClass.TcList();
                    MessageBox.Show("Запись удалена!");

                }
            }
        }
    }
}
