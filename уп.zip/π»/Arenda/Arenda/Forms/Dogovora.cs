﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Arenda.Forms
{
    public partial class Dogovora : Form
    {
        public Dogovora()
        {
            InitializeComponent();
        }

        private void Dogovora_Load(object sender, EventArgs e)
        {
            Clases.DogovoraClass.DogovoraList();
            dataGridView1.DataSource = Clases.DogovoraClass.dtDogovora;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Forms.Add.AddDogovor AddDogovor = new Forms.Add.AddDogovor();
            AddDogovor.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Вы уверены что хотите удалить этот договор?", "Удаление записи", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if (result == DialogResult.Yes)
            {
                if (Clases.DogovoraClass.DeleteDogovor(dataGridView1.CurrentRow.Cells[0].Value.ToString()) == true)
                {
                    Clases.DogovoraClass.DogovoraList();
                    MessageBox.Show("Запись удалена!");

                }
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            try
            {
                string filename = @"Arenda.csv";
                FileStream fsoutput = new FileStream(filename, FileMode.Create, FileAccess.Write);
                StreamWriter swoutput = new StreamWriter(fsoutput, System.Text.Encoding.UTF8);
                swoutput.WriteLine("Номер Договора; Дата начала; Дата Окончания; Сотрудник; Клиент; Код Помещения");
                for (int i = 1; i < dataGridView1.Rows.Count; i++)
                {
                    swoutput.Write(dataGridView1.Rows[i].Cells[0].Value.ToString());  
                    swoutput.Write(";");

                    string date1 = dataGridView1.Rows[i].Cells[1].Value.ToString().Substring(0, 10);
                    swoutput.Write(date1);
                    swoutput.Write(";");

                    string date2 = dataGridView1.Rows[i].Cells[2].Value.ToString().Substring(0, 10);
                    swoutput.Write(date2);
                    swoutput.Write(";");

                    swoutput.Write(dataGridView1.Rows[i].Cells[3].Value.ToString());
                    swoutput.Write(";");

                    swoutput.Write(dataGridView1.Rows[i].Cells[4].Value.ToString());
                    swoutput.Write(";");

                    swoutput.Write(dataGridView1.Rows[i].Cells[5].Value.ToString());
                    swoutput.Write(";");

                    swoutput.WriteLine();
                }
                swoutput.Close();
                MessageBox.Show("Успешно");
            }
            catch
            {
                MessageBox.Show("Ошибка");
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            try
            {
                string filename = @"Arenda.doc";
                FileStream fsoutput = new FileStream(filename, FileMode.Create, FileAccess.Write);
                StreamWriter swoutput = new StreamWriter(fsoutput, System.Text.Encoding.UTF8);
                swoutput.WriteLine("Номер Договора; Дата начала; Дата Окончания; Сотрудник; Клиент; Код Помещения");
                for (int i = 1; i < dataGridView1.Rows.Count; i++)
                {
                    swoutput.Write(dataGridView1.Rows[i].Cells[0].Value.ToString());
                    swoutput.Write(";");

                    string date1 = dataGridView1.Rows[i].Cells[1].Value.ToString().Substring(0, 10);
                    swoutput.Write(date1);
                    swoutput.Write(";");

                    string date2 = dataGridView1.Rows[i].Cells[2].Value.ToString().Substring(0, 10);
                    swoutput.Write(date2);
                    swoutput.Write(";");

                    swoutput.Write(dataGridView1.Rows[i].Cells[3].Value.ToString());
                    swoutput.Write(";");

                    swoutput.Write(dataGridView1.Rows[i].Cells[4].Value.ToString());
                    swoutput.Write(";");

                    swoutput.Write(dataGridView1.Rows[i].Cells[5].Value.ToString());
                    swoutput.Write(";");

                    swoutput.WriteLine();
                }
                swoutput.Close();
                MessageBox.Show("Успешно");
            }
            catch
            {
                MessageBox.Show("Ошибка");
            }
        }
    }
}
