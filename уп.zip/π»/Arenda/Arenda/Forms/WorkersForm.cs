﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Arenda.Forms
{
    public partial class WorkersForm : Form
    {
        public WorkersForm()
        {
            InitializeComponent();
        }

        private void WorkersForm_Load(object sender, EventArgs e)
        {
            if(Clases.AutorizationClass.Role == "GenDir")
            {
                button1.Visible = true;
                button2.Visible = true;
            }
            if(Clases.AutorizationClass.Role == "manager")
            {
                button1.Visible = false;
                button2.Visible = false;
            }
            Clases.WorkersClass.WorkersList();
            dataGridView1.DataSource = Clases.WorkersClass.dtWorkers;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        static public string id, fullname, dr, phonenumber, nomerpasporta, namedolg, status;

        private void button1_Click(object sender, EventArgs e)
        {
            Forms.AddWorkersForm AddForm = new Forms.AddWorkersForm();
            AddForm.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (Clases.WorkersClass.Uvolit(dataGridView1.CurrentRow.Cells[0].Value.ToString()) == true)
            {
                this.Close();
                MessageBox.Show("Запись изменена");
                Clases.WorkersClass.WorkersList();
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            id = dataGridView1.CurrentRow.Cells[0].Value.ToString();
            fullname = dataGridView1.CurrentRow.Cells[1].Value.ToString();
            dr = dataGridView1.CurrentRow.Cells[2].Value.ToString();
            phonenumber = dataGridView1.CurrentRow.Cells[3].Value.ToString();
            nomerpasporta = dataGridView1.CurrentRow.Cells[4].Value.ToString();
            namedolg = dataGridView1.CurrentRow.Cells[5].Value.ToString();
            status = dataGridView1.CurrentRow.Cells[6].Value.ToString();
            Forms.EditForm EditForm = new Forms.EditForm();
            EditForm.Show();
        }
    }
}
