﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Arenda.Forms
{
    public partial class EditForm : Form
    {
        public EditForm()
        {
            InitializeComponent();
        }

        private void EditForm_Load(object sender, EventArgs e)
        {
            Clases.WorkersClass.FioComboBox();
            comboBox1.DataSource = Clases.WorkersClass.dtFioComboBox;
            comboBox1.ValueMember = "idworker";
            comboBox1.DisplayMember = "fullname";

            Clases.WorkersClass.DolgnComboBox();
            comboBox2.DataSource = Clases.WorkersClass.dtDolgnComboBox;
            comboBox2.ValueMember = "iddolgnost";
            comboBox2.DisplayMember = "namedolg";

            Clases.WorkersClass.StatusComboBoc();
            comboBox3.DataSource = Clases.WorkersClass.dtStatusComboBox;
            comboBox3.ValueMember = "idworker";
            comboBox3.DisplayMember = "status";

            dateTimePicker1.Text = Forms.WorkersForm.dr;
            textBox1.Text = Forms.WorkersForm.phonenumber;
            textBox2.Text = Forms.WorkersForm.nomerpasporta;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(Clases.WorkersClass.EditSave(Forms.WorkersForm.id,comboBox1.SelectedValue.ToString(),dateTimePicker1.Text,textBox1.Text,textBox2.Text,comboBox2.SelectedValue.ToString(),comboBox3.SelectedValue.ToString())==true)
            {
                this.Close();
                MessageBox.Show("Запись изменена");
                Clases.WorkersClass.WorkersList();
            }
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar < '0' || e.KeyChar > '9') && (e.KeyChar != 8))
                e.Handled = true;
        }

        private void textBox2_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar < '0' || e.KeyChar > '9') && (e.KeyChar != 8))
                e.Handled = true;
        }
    }
}
