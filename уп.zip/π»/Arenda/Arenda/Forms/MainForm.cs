﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Arenda.Forms
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form Authorization = Application.OpenForms[0];
            Authorization.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Forms.WorkersForm WorkersForm = new Forms.WorkersForm();
            WorkersForm.Show();
        }

        private void MainForm_Load(object sender, EventArgs e)
        {

        }

        private void назадToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form Authorization = Application.OpenForms[0];
            Authorization.Show();
        }

        private void сотрудникиToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Forms.WorkersForm WorkersForm = new Forms.WorkersForm();
            WorkersForm.Show();
        }

        private void должностиToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Forms.DolgnostiForm DolgnostiForm = new Forms.DolgnostiForm();
            DolgnostiForm.Show();
        }

        private void торговыеЦентрыToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Forms.TorgovieCentriForm TcForm = new Forms.TorgovieCentriForm();
            TcForm.Show();
        }

        private void клиентыToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Forms.Klienti Klienti = new Forms.Klienti();
            Klienti.Show();
        }

        private void договораToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Forms.Dogovora Dogovora = new Forms.Dogovora();
            Dogovora.Show();
        }

        private void оплатаToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Forms.Oplata Oplata = new Forms.Oplata();
            Oplata.Show();
        }
    }
}
