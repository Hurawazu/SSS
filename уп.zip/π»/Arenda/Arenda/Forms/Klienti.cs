﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Arenda.Forms
{
    public partial class Klienti : Form
    {
        public Klienti()
        {
            InitializeComponent();
        }

        private void Klienti_Load(object sender, EventArgs e)
        {
            Clases.KlientiClass.KlientList();
            dataGridView1.DataSource = Clases.KlientiClass.dtKlient;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Forms.Add.AddKlient AddKlient = new Forms.Add.AddKlient();
            AddKlient.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
          
            
                DialogResult result = MessageBox.Show("Вы уверены что хотите удалить этого клиента?", "Удаление записи", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                if (result == DialogResult.Yes)
                {
                    if (Clases.KlientiClass.DeleteKlient(dataGridView1.CurrentRow.Cells[0].Value.ToString()) == true)
                    {
                        Clases.KlientiClass.KlientList();
                        MessageBox.Show("Запись удалена!");

                    }
                }
            
        }
    }
}
