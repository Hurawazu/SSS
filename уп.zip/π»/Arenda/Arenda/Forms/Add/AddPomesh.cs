﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Arenda.Forms.Add
{
    public partial class AddPomesh : Form
    {
        public AddPomesh()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (Clases.TcClass.AddPomesh(textBox1.Text, textBox2.Text, textBox3.Text, textBox4.Text, checkBox1.Checked, checkBox2.Checked, checkBox3.Checked, comboBox1.SelectedValue.ToString() ) == true)
            {
                this.Close();
                MessageBox.Show("Запись добавлена");
                Clases.TcClass.TcList();

            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void AddPomesh_Load(object sender, EventArgs e)
        {
            Clases.TcClass.AddComboBoxP();
            comboBox1.DataSource = Clases.TcClass.dtAddTc;
            comboBox1.ValueMember = "idtc";
            comboBox1.DisplayMember = "adress";
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar < '0' || e.KeyChar > '9') && (e.KeyChar != 8))
                e.Handled = true;
        }

        private void textBox2_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar < '0' || e.KeyChar > '9') && (e.KeyChar != 8))
                e.Handled = true;
        }

        private void textBox3_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar < '0' || e.KeyChar > '9') && (e.KeyChar != 8))
                e.Handled = true;
        }

        private void textBox4_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar < '0' || e.KeyChar > '9') && (e.KeyChar != 8))
                e.Handled = true;
        }
    }
}
