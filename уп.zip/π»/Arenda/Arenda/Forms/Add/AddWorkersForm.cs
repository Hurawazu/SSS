﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Arenda.Forms
{
    public partial class AddWorkersForm : Form
    {
        public AddWorkersForm()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(Clases.WorkersClass.AddWorker(textBox1.Text, dateTimePicker1.Text, textBox2.Text, textBox3.Text, comboBox1.SelectedValue.ToString(), textBox5.Text,textBox4.Text) ==true)
            {
                this.Close();
                MessageBox.Show("Запись добавлена");
                Clases.WorkersClass.WorkersList();

            }
        }

        private void AddWorkersForm_Load(object sender, EventArgs e)
        {
            Clases.WorkersClass.AddComboBoc();
            comboBox1.DataSource = Clases.WorkersClass.dtAddComboBox;
            comboBox1.ValueMember = "iddolgnost";
            comboBox1.DisplayMember = "namedolg";
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar < 'А' || e.KeyChar > 'я') && (e.KeyChar != 8))
                e.Handled = true;
        }

        private void textBox2_KeyUp(object sender, KeyEventArgs e)
        {

        }

        private void textBox2_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar < '0' || e.KeyChar > '9') && (e.KeyChar != 8))
                e.Handled = true;
        }

        private void textBox3_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar < '0' || e.KeyChar > '9') && (e.KeyChar != 8))
                e.Handled = true;
        }
    }
}
