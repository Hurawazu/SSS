﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Arenda.Forms.Add
{
    public partial class AddDogovor : Form
    {
        public AddDogovor()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void AddDogovor_Load(object sender, EventArgs e)
        {
            Clases.DogovoraClass.AddComboBoxMenedger();
            comboBox1.DataSource = Clases.DogovoraClass.dtComboboxMenedger;
            comboBox1.ValueMember = "idworker";
            comboBox1.DisplayMember = "fullname";

            Clases.DogovoraClass.AddComboBoxKlient();
            comboBox2.DataSource = Clases.DogovoraClass.dtComboboxKlient;
            comboBox2.ValueMember = "idklient";
            comboBox2.DisplayMember = "fio";

            Clases.DogovoraClass.AddComboBoxPomesh();
            comboBox3.DataSource = Clases.DogovoraClass.dtComboboxPomesh;
            comboBox3.ValueMember = "idpomesh";
            comboBox3.DisplayMember = "idpomesh";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (Clases.DogovoraClass.AddDogovor(textBox1.Text, dateTimePicker1.Text, dateTimePicker2.Text, comboBox1.SelectedValue.ToString(), comboBox2.SelectedValue.ToString(), comboBox3.SelectedValue.ToString()) == true) 
            {
                if (dateTimePicker1.Value <= dateTimePicker2.Value)
                {
                    this.Close();
                    MessageBox.Show("Запись добавлена");
                    Clases.DogovoraClass.DogovoraList();
                }
                else
                    MessageBox.Show("Дата введена неверно");
            }
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar < '0' || e.KeyChar > '9') && (e.KeyChar != 8))
                e.Handled = true;
        }
    }
}
