﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Arenda
{
    public partial class Autorization : Form
    {
        public Autorization()
        {
            InitializeComponent();
        }

        private void Autorization_Load(object sender, EventArgs e)
        {
            if (Clases.AutorizationClass.OpenConnect()==false)
            { this.Close(); }

            
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Clases.AutorizationClass.CloseConnect();
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text != "" && textBox2.Text != "")
            {
                Clases.AutorizationClass.Autorization(textBox1.Text, textBox2.Text);
                switch(Clases.AutorizationClass.Role)
                {
                    case null:
                        //MessageBox.Show("Данные введены неверно или отсутсвуют!");
                        break;
                    case "manager":
                        this.Hide();
                        Forms.MainForm MainForm = new Forms.MainForm();
                        MainForm.Show();
                        break;
                    case "GenDir":
                        this.Hide();
                        Forms.MainForm MainForm1 = new Forms.MainForm();
                        MainForm1.Show();
                        break;

                }
                Clases.Platezh.OplataListAuto(DateTime.Now.Date.ToString("yyyy-MM-dd"));
               
            

            }
        }
    }
}
