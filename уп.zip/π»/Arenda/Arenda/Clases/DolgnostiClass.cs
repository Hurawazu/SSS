﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using System.Data;

namespace Arenda.Clases
{
    class DolgnostiClass
    {
        static public DataTable dtDolgnosti = new DataTable();
        static public void DolgnostList()
        {
            Clases.AutorizationClass.MyComm.CommandText = @"Select * from dolgnosti";
            Clases.AutorizationClass.MyAdapter = new MySqlDataAdapter(Clases.AutorizationClass.MyComm);
            dtDolgnosti.Clear();
            Clases.AutorizationClass.MyAdapter.Fill(dtDolgnosti);
        }

        static public bool DeleteDolg(string idpos)
        {
            try
            {
                Clases.AutorizationClass.MyComm.CommandText = @"select count(iddolgnost) from workers where iddolgnost = '" + idpos + "'";
                object result = Clases.AutorizationClass.MyComm.ExecuteScalar();
                int rez = Convert.ToInt32(result);
                if (rez>0)
                {
                    System.Windows.Forms.MessageBox.Show("Невозможно удалить должность!");
                    return false;
                }
                else
                {
                    Clases.AutorizationClass.MyComm.CommandText = @"Delete from dolgnosti where iddolgnost = '" + idpos + "'";
                    if(Clases.AutorizationClass.MyComm.ExecuteNonQuery()>0)
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                }
            }
            catch
            {
                System.Windows.Forms.MessageBox.Show("Ошибка при удалении должности!");
                return false;
            }
        }

        static public bool AddDolgnost(string dolgnost)
        {
            try
            {

                Clases.AutorizationClass.MyComm.CommandText = @"insert into dolgnosti values(NULL, '" + dolgnost + "')";
                if (Clases.AutorizationClass.MyComm.ExecuteNonQuery() > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch
            {
                System.Windows.Forms.MessageBox.Show("Ошибка при добавлени сотрудника");
                return false;
            }
        }
    }
    }

