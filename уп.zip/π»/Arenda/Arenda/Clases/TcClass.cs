﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using System.Data;

namespace Arenda.Clases
{
    class TcClass
    {
        static public DataTable dtTc = new DataTable();
        static public DataTable dtTcN = new DataTable();
        static public DataTable dtAddTc = new DataTable();

        static public void TcList()
        {
            Clases.AutorizationClass.MyComm.CommandText = @"Select idtc, adress, etazhi, workers.fullname from torgcenter, workers where torgcenter.idadm = workers.idworker";
            Clases.AutorizationClass.MyAdapter = new MySqlDataAdapter(Clases.AutorizationClass.MyComm);
            dtTc.Clear();
            Clases.AutorizationClass.MyAdapter.Fill(dtTc);
        }

        static public void TcNumber(string TcNom)
        {
            Clases.AutorizationClass.MyComm.CommandText = @"Select idpomesh, ploshad, etazh, nomer_pomesh,okna,ubornaya,kondei, cena_mes from pomesh where idtc = '" + TcNom+"'";
            Clases.AutorizationClass.MyAdapter = new MySqlDataAdapter(Clases.AutorizationClass.MyComm);
            dtTcN.Clear();
            Clases.AutorizationClass.MyAdapter.Fill(dtTcN);
        }

        static public void AddComboBox()
        {
            Clases.AutorizationClass.MyComm.CommandText = @"select idworker, fullname from workers where iddolgnost = 1";
            Clases.AutorizationClass.MyAdapter = new MySqlDataAdapter(Clases.AutorizationClass.MyComm);
            dtAddTc.Clear();
            Clases.AutorizationClass.MyAdapter.Fill(dtAddTc);
        }

        static public bool AddTc(string adress, string etazhi, string adm)
        {
            try
            {

                Clases.AutorizationClass.MyComm.CommandText = @"insert into torgcenter values(NULL, '" + adress + "', '"+ etazhi + "','"+ adm + "')";
                if (Clases.AutorizationClass.MyComm.ExecuteNonQuery() > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch
            {
                System.Windows.Forms.MessageBox.Show("Ошибка при добавлени торгового центра");
                return false;
            }
        }

        static public bool AddPomesh(string ploshad, string cena_mes, string etazh, string nomer, bool okna, bool ubarnaya, bool kondei, string tc)
        {
            try
            {

                Clases.AutorizationClass.MyComm.CommandText = @"insert into pomesh values(NULL, '" + ploshad + "', '" + cena_mes + "','" + etazh + "', '" + nomer + "', '" + Convert.ToInt32(okna) + "','" + Convert.ToInt32(ubarnaya) + "', '" + Convert.ToInt32(kondei) + "', '" + tc + "')";
                if (Clases.AutorizationClass.MyComm.ExecuteNonQuery() > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch
            {
                System.Windows.Forms.MessageBox.Show("Ошибка при добавлени помещения");
                return false;
            }
        }

        static public void AddComboBoxP()
        {
            Clases.AutorizationClass.MyComm.CommandText = @"select idtc, adress from torgcenter ";
            Clases.AutorizationClass.MyAdapter = new MySqlDataAdapter(Clases.AutorizationClass.MyComm);
            dtAddTc.Clear();
            Clases.AutorizationClass.MyAdapter.Fill(dtAddTc);
        }

        static public bool DeleteTc(string idpos)
        {
            try
            {
                Clases.AutorizationClass.MyComm.CommandText = @"select count(idtc) from pomesh where idtc = '" + idpos + "'";
                object result = Clases.AutorizationClass.MyComm.ExecuteScalar();
                int rez = Convert.ToInt32(result);
                if (rez > 0)
                {
                    System.Windows.Forms.MessageBox.Show("Невозможно удалить торговый центер!");
                    return false;
                }
                else
                {
                    Clases.AutorizationClass.MyComm.CommandText = @"Delete from torgcenter where idtc = '" + idpos + "'";
                    if (Clases.AutorizationClass.MyComm.ExecuteNonQuery() > 0)
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                }
            }
            catch
            {
                System.Windows.Forms.MessageBox.Show("Ошибка при удалении торгового центра!");
                return false;
            }
        }

        static public bool DeletePomesh(string idpost)
        {
            try
            {
             
                    Clases.AutorizationClass.MyComm.CommandText = @"Delete from pomesh where idpomesh = '" + idpost + "'";
                    if (Clases.AutorizationClass.MyComm.ExecuteNonQuery() > 0)
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                
            }
            catch
            {
                System.Windows.Forms.MessageBox.Show("Ошибка при удалении помещения!");
                return false;
            }
        }
    } 
}
