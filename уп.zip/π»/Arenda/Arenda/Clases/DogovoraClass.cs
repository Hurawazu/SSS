﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using System.Data;

namespace Arenda.Clases
{
    class DogovoraClass
    {
        static public DataTable dtDogovora = new DataTable();
        static public DataTable dtComboboxMenedger = new DataTable();
        static public DataTable dtComboboxKlient = new DataTable();
        static public DataTable dtComboboxPomesh = new DataTable();

        static public void DogovoraList()
        {
            Clases.AutorizationClass.MyComm.CommandText = @"Select name, datanach, datakon, workers.fullname, klient.fio, idpomesh from workers, dogovora, klient where workers.idworker = dogovora.idworker and dogovora.idklient = klient.idklient";
            Clases.AutorizationClass.MyAdapter = new MySqlDataAdapter(Clases.AutorizationClass.MyComm);
            dtDogovora.Clear();
            Clases.AutorizationClass.MyAdapter.Fill(dtDogovora);
        }

        static public void AddComboBoxMenedger()
        {
            Clases.AutorizationClass.MyComm.CommandText = @"select idworker, fullname from workers where iddolgnost = 2";
            Clases.AutorizationClass.MyAdapter = new MySqlDataAdapter(Clases.AutorizationClass.MyComm);
            dtComboboxMenedger.Clear();
            Clases.AutorizationClass.MyAdapter.Fill(dtComboboxMenedger);
        }

        static public void AddComboBoxKlient()
        {
            Clases.AutorizationClass.MyComm.CommandText = @"select idklient, fio from klient";
            Clases.AutorizationClass.MyAdapter = new MySqlDataAdapter(Clases.AutorizationClass.MyComm);
            dtComboboxKlient.Clear();
            Clases.AutorizationClass.MyAdapter.Fill(dtComboboxKlient);
        }

        static public void AddComboBoxPomesh()
        {
            Clases.AutorizationClass.MyComm.CommandText = @"select idpomesh from pomesh";
            Clases.AutorizationClass.MyAdapter = new MySqlDataAdapter(Clases.AutorizationClass.MyComm);
            dtComboboxPomesh.Clear();
            Clases.AutorizationClass.MyAdapter.Fill(dtComboboxPomesh);
        }

        static public bool AddDogovor(string nomer, string nach, string kon, string menedger, string klient, string pomesh)
        {
            
            try
            {
                DateTime date1 = Convert.ToDateTime(nach);
                DateTime date2 = Convert.ToDateTime(kon);
                Clases.AutorizationClass.MyComm.CommandText = "insert into dogovora values(NULL,'" + nomer + "', '" + date1.ToString("yyyy-MM-dd") + "', '" + date2.ToString("yyyy-MM-dd") + "', '" + menedger + "', '" + klient + "', '" + pomesh + "')";
                if (Clases.AutorizationClass.MyComm.ExecuteNonQuery() > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch
            {
                System.Windows.Forms.MessageBox.Show("Ошибка при добавлени договора");
                return false;

            }
        }

        static public bool DeleteDogovor(string idpost)
        {
            try
            {

                Clases.AutorizationClass.MyComm.CommandText = @"Delete from dogovora where name = '" + idpost + "'";
                if (Clases.AutorizationClass.MyComm.ExecuteNonQuery() > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }

            }
            catch
            {
                System.Windows.Forms.MessageBox.Show("Ошибка при удалении договора!");
                return false;
            }
        }
    }
}
