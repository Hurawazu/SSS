﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using System.Data;

namespace Arenda.Clases
{
    class AutorizationClass
    {
        static public string MyBase = "Database = arenda; DataSource = localhost; User=root; Password = 3450; Charset = utf8mb4";
        static public MySqlConnection MyConnect;
        static public MySqlDataAdapter MyAdapter;
        static public MySqlCommand MyComm;
        static public MySqlCommand MyCommDN;
        static public MySqlCommand MyCommDK;
        static public MySqlCommand MyCommOP;
        static public MySqlCommand MyCommND;
        static public MySqlCommand MyCommDataNach;
        static public MySqlCommand MyCommIdPomesh;
        static public MySqlCommand MyCommCena;



        static public bool OpenConnect()
        {
            try
            {
                MyConnect = new MySqlConnection(MyBase);
                MyConnect.Open();
                MyComm = new MySqlCommand();
                MyComm.Connection = MyConnect;
                MyCommDN = new MySqlCommand();
                MyCommDN.Connection = MyConnect;
                MyAdapter = new MySqlDataAdapter(MyComm);
                MyAdapter = new MySqlDataAdapter(MyCommDN);
                MyCommDK = new MySqlCommand();
                MyCommDK.Connection = MyConnect;
                MyAdapter = new MySqlDataAdapter(MyCommDK);
                MyCommOP = new MySqlCommand();
                MyCommOP.Connection = MyConnect;
                MyAdapter = new MySqlDataAdapter(MyCommOP);
                MyCommND = new MySqlCommand();
                MyCommND.Connection = MyConnect;
                MyAdapter = new MySqlDataAdapter(MyCommND);
                MyCommDataNach = new MySqlCommand();
                MyCommDataNach.Connection = MyConnect;
                MyAdapter = new MySqlDataAdapter(MyCommDataNach);
                MyCommIdPomesh = new MySqlCommand();
                MyCommIdPomesh.Connection = MyConnect;
                MyAdapter = new MySqlDataAdapter(MyCommIdPomesh);
                MyCommCena = new MySqlCommand();
                MyCommCena.Connection = MyConnect;
                MyAdapter = new MySqlDataAdapter(MyCommCena);
                return true;
            }
            catch
            {
                System.Windows.Forms.MessageBox.Show("Ошибка подключения к БД");
                return false;
            }
        }
        static public void CloseConnect()
        {
            MyConnect.Close();
        }
        public static string User;
        static public string Role;
        static public string Autorization(string login, string password)
        {
            try
            {
                Role = null;
                string SQL = @"SELECT login,password from workers where ((status='"+"работает"+"' ) and (login='" + login+ "') and (password='" +password+ "'))";
                MyComm.CommandText = SQL;
                Object result = MyComm.ExecuteScalar();
                if(result != null && login == "first")
                {
                    User = result.ToString();
                    return Role = "GenDir";
                }
                else
                {
                    if (result != null && login != "first")
                    {
                        User = result.ToString();
                        return Role = "manager";
                    }
                    else
                    {
                        return Role = null;
                    }
                }
            }
            catch
            {
                System.Windows.Forms.MessageBox.Show("Ошибка авторизации");
                return login = null;
            }
        }
    }
}
