﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using System.Data;

namespace Arenda.Clases
{
    class Platezh
    {
        static public DataTable dtPlatezhi = new DataTable();
        static public DataTable dtDataOplat = new DataTable();

        static public void OplataList()
        {
            Clases.AutorizationClass.MyComm.CommandText = @"select * from oplata";
            Clases.AutorizationClass.MyAdapter = new MySqlDataAdapter(Clases.AutorizationClass.MyComm);
            dtPlatezhi.Clear();
            Clases.AutorizationClass.MyAdapter.Fill(dtPlatezhi);
        }

        static public bool OplataListAuto(string tekdate)
        {

            Clases.AutorizationClass.MyComm.CommandText = @"select * from dogovora where datakon >= '" + tekdate + "' and datanach >= '" + tekdate + "'";  // вывод всех данных из таблицы dogovora в вр таблицу dtDataOplat
            Clases.AutorizationClass.MyAdapter = new MySqlDataAdapter(Clases.AutorizationClass.MyComm);
            dtDataOplat.Clear();
            Clases.AutorizationClass.MyAdapter.Fill(dtDataOplat);
           // try
            {
                for (int i = 0; i < dtDataOplat.Rows.Count; i++)
                {
                    string Ndog = dtDataOplat.Select(); //ОШИБКА!!!
                    Clases.AutorizationClass.MyCommND.CommandText = Ndog;
                    string NdogV = Convert.ToString(Clases.AutorizationClass.MyCommND.ExecuteScalar()); // вывод номера договора в переменную

                    string DataNach = @"select datanach from dogovora where name = '" + NdogV + "'";
                    Clases.AutorizationClass.MyCommDataNach.CommandText = DataNach;
                    DateTime DatanachV = Convert.ToDateTime(Clases.AutorizationClass.MyCommDataNach.ExecuteScalar()); //вывод даты начала договора в перемменную

                    if (DatanachV >= DateTime.Now.Date)
                    {
                        string idpomesh = @"select idpomesh from dogovora where name = '" + NdogV + "'";
                        Clases.AutorizationClass.MyCommIdPomesh.CommandText = idpomesh;
                        string idpomeshV = Convert.ToString(Clases.AutorizationClass.MyCommIdPomesh.ExecuteScalar()); // вывод id помещения в переменную

                        string cena_mes = @"select cena_mes from pomesh where idpomesh = '" + idpomeshV + "'";
                        Clases.AutorizationClass.MyCommCena.CommandText = cena_mes;
                        string cena_mesV = Convert.ToString(Clases.AutorizationClass.MyCommCena.ExecuteScalar());    //вывод цены за месяц в переменную

                        Clases.AutorizationClass.MyComm.CommandText = "insert into oplata values(NULL, '" + NdogV + "', '" + DatanachV.ToString("yyyy-MM-dd") + "', '" + cena_mesV + "' )";
                    }
                }
                if (Clases.AutorizationClass.MyComm.ExecuteNonQuery() > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }           
            //catch
            {
                System.Windows.Forms.MessageBox.Show("Загрузки оплаты");
                return false;

            }
        }
    
            
            
        

      

        
    }
}
