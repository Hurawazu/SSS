﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using System.Data;

namespace Arenda.Clases
{
    class KlientiClass
    {
        static public DataTable dtKlient = new DataTable();

        static public void KlientList()
        {
            Clases.AutorizationClass.MyComm.CommandText = @"Select idklient,fio, phonenumber, nomerpasp, email from klient";
                                                          
            Clases.AutorizationClass.MyAdapter = new MySqlDataAdapter(Clases.AutorizationClass.MyComm);
            dtKlient.Clear();
            Clases.AutorizationClass.MyAdapter.Fill(dtKlient);
        }

        static public bool AddKlient(string fio, string email, string phonenumber, string nomerpasporta)
        {
            try
            {

                Clases.AutorizationClass.MyComm.CommandText = @"insert into klient values(NULL, '" + fio + "', '" + phonenumber + "', '" + nomerpasporta + "', '" + email + "')";
                if (Clases.AutorizationClass.MyComm.ExecuteNonQuery() > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch
            {
                System.Windows.Forms.MessageBox.Show("Ошибка при добавлени клиента");
                return false;
            }
        }

        static public bool DeleteKlient(string idpost)
        {
            try
            {

                Clases.AutorizationClass.MyComm.CommandText = @"Delete from klient where idklient = '" + idpost + "'";
                if (Clases.AutorizationClass.MyComm.ExecuteNonQuery() > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }

            }
            catch
            {
                System.Windows.Forms.MessageBox.Show("Ошибка при удалении клиента!");
                return false;
            }
        }
    }
}
