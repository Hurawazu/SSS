﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;

namespace Arenda.Clases
{
    public class EmailCheck
    {
        public static bool EmailCh(string text)
        {
            Regex regex = new Regex(@"^[a-zA-Z\d]+\@[a-zA-Z\d]+\.[a-zA-Z]+$");
         
            if (regex.IsMatch(text) == true)
                return true;
            else
                return false;
        }
    }
}
