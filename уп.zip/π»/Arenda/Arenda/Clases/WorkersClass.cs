﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using System.Data;

namespace Arenda.Clases
{
    class WorkersClass
    {
        static public DataTable dtWorkers = new DataTable();
        static public DataTable dtFioComboBox = new DataTable();
        static public DataTable dtDolgnComboBox = new DataTable();
        static public DataTable dtStatusComboBox = new DataTable();
        static public DataTable dtAddComboBox = new DataTable();

        static public void WorkersList()
        {
            Clases.AutorizationClass.MyComm.CommandText = @"Select idworker, fullname, dr, phonenumber, nomerpasporta, namedolg, status from workers, dolgnosti
                                                            where workers.iddolgnost = dolgnosti.iddolgnost";
            Clases.AutorizationClass.MyAdapter = new MySqlDataAdapter(Clases.AutorizationClass.MyComm);
            dtWorkers.Clear();
            Clases.AutorizationClass.MyAdapter.Fill(dtWorkers);
        }

        static public void FioComboBox()
        {
            Clases.AutorizationClass.MyComm.CommandText = @"select idworker, fullname from workers";
            Clases.AutorizationClass.MyAdapter = new MySqlDataAdapter(Clases.AutorizationClass.MyComm);
            dtFioComboBox.Clear();
            Clases.AutorizationClass.MyAdapter.Fill(dtFioComboBox);
        }
        static public void DolgnComboBox()
        {
            Clases.AutorizationClass.MyComm.CommandText = @"select iddolgnost, namedolg from dolgnosti";
            Clases.AutorizationClass.MyAdapter = new MySqlDataAdapter(Clases.AutorizationClass.MyComm);
            dtDolgnComboBox.Clear();
            Clases.AutorizationClass.MyAdapter.Fill(dtDolgnComboBox);
        }

        static public void StatusComboBoc()
        {
            Clases.AutorizationClass.MyComm.CommandText = @"select idworker, status from workers";
            Clases.AutorizationClass.MyAdapter = new MySqlDataAdapter(Clases.AutorizationClass.MyComm);
            dtStatusComboBox.Clear();
            Clases.AutorizationClass.MyAdapter.Fill(dtStatusComboBox);
        }

        static public bool EditSave(string id, string fullname, string dr, string phonenumber, string nomerpasporta, string namedolg, string status)
        {
            try
            {


                DateTime date1 = Convert.ToDateTime(dr);
                Clases.AutorizationClass.MyComm.CommandText = @"update workers set fullname= '" + fullname + "', dr= '" + dr + "', phonenumber= '" + phonenumber + "', nomerpasporta= '" + nomerpasporta + "', iddolgnost= '" + namedolg + "', status= '" + status + "'";
                if (Clases.AutorizationClass.MyComm.ExecuteNonQuery() > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch
            {
                System.Windows.Forms.MessageBox.Show("Ошибка при изменении данных");
                return false;
            }
        }
        static public bool Uvolit(string id)
        {
            try
            {
                Clases.AutorizationClass.MyComm.CommandText = @"update workers set status='" + "не работает" + "' where idworker = '"+id+"'";
                if (Clases.AutorizationClass.MyComm.ExecuteNonQuery() > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch
            {
                System.Windows.Forms.MessageBox.Show("Ошибка при увольнении");
                return false;
            }
        }
        static public void AddComboBoc()
        {
            Clases.AutorizationClass.MyComm.CommandText = @"select iddolgnost, namedolg from dolgnosti";
            Clases.AutorizationClass.MyAdapter = new MySqlDataAdapter(Clases.AutorizationClass.MyComm);
            dtAddComboBox.Clear();
            Clases.AutorizationClass.MyAdapter.Fill(dtAddComboBox);
        }

        static public bool AddWorker(string fullname, string dr, string phonenumber, string nomerpasporta, string dolgnost, string login, string password)
        {
            try
            {
               
                DateTime date1 = Convert.ToDateTime(dr);
                Clases.AutorizationClass.MyComm.CommandText = @"insert into workers values(NULL, '" + fullname + "', '" + date1.ToString("yyyy-MM-dd") + "', '" + phonenumber + "', '" + nomerpasporta + "', '" + dolgnost + "', '" + login + "', '" + password + "','" + "работает" + "')";
                if(Clases.AutorizationClass.MyComm.ExecuteNonQuery()>0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch
            {
                System.Windows.Forms.MessageBox.Show("Ошибка при добавлени сотрудника");
                return false;
            }
        }
    }
}
