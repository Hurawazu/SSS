CREATE DATABASE  IF NOT EXISTS `arenda` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `arenda`;
-- MySQL dump 10.13  Distrib 8.0.28, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: arenda
-- ------------------------------------------------------
-- Server version	8.0.28

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `dogovora`
--

DROP TABLE IF EXISTS `dogovora`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `dogovora` (
  `iddogovora` int NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL,
  `datanach` date DEFAULT NULL,
  `datakon` date DEFAULT NULL,
  `stoimost` varchar(45) DEFAULT NULL,
  `idworker` int DEFAULT NULL,
  `idklient` int DEFAULT NULL,
  `idpomesh` int DEFAULT NULL,
  PRIMARY KEY (`iddogovora`),
  KEY `a5_idx` (`idworker`),
  KEY `a6_idx` (`idklient`),
  KEY `a11_idx` (`idpomesh`),
  CONSTRAINT `a11` FOREIGN KEY (`idpomesh`) REFERENCES `pomesh` (`idpomesh`),
  CONSTRAINT `a5` FOREIGN KEY (`idworker`) REFERENCES `workers` (`idworker`),
  CONSTRAINT `a6` FOREIGN KEY (`idklient`) REFERENCES `klient` (`idklient`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dogovora`
--

LOCK TABLES `dogovora` WRITE;
/*!40000 ALTER TABLE `dogovora` DISABLE KEYS */;
/*!40000 ALTER TABLE `dogovora` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dolgnosti`
--

DROP TABLE IF EXISTS `dolgnosti`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `dolgnosti` (
  `iddolgnost` int NOT NULL AUTO_INCREMENT,
  `namedolg` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`iddolgnost`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dolgnosti`
--

LOCK TABLES `dolgnosti` WRITE;
/*!40000 ALTER TABLE `dolgnosti` DISABLE KEYS */;
INSERT INTO `dolgnosti` VALUES (1,'Ген Директор'),(2,'Менеджер');
/*!40000 ALTER TABLE `dolgnosti` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `klient`
--

DROP TABLE IF EXISTS `klient`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `klient` (
  `idklient` int NOT NULL AUTO_INCREMENT,
  `fio` varchar(45) DEFAULT NULL,
  `phonenumber` varchar(11) DEFAULT NULL,
  `nomerpasp` varchar(10) DEFAULT NULL,
  `email` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`idklient`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `klient`
--

LOCK TABLES `klient` WRITE;
/*!40000 ALTER TABLE `klient` DISABLE KEYS */;
INSERT INTO `klient` VALUES (1,'Иванов Руслан Тимурович','79969326402','4717098376','ivanov23@yandex.ru'),(2,'Лебедева Анастасия андреевна','79213028374','4723849378','lebedeva2331@gmail.com'),(3,'Лисовец Дмитрий Андреевич','79910459285','4710938401','lisovets@mail.ru');
/*!40000 ALTER TABLE `klient` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oplata`
--

DROP TABLE IF EXISTS `oplata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `oplata` (
  `idplatzha` int NOT NULL AUTO_INCREMENT,
  `date_platezha` date DEFAULT NULL,
  `summa` float DEFAULT NULL,
  `zadolzhennost` tinyint DEFAULT NULL,
  `namedogovora` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`idplatzha`),
  KEY `a12_idx` (`idplatzha`),
  CONSTRAINT `a12` FOREIGN KEY (`idplatzha`) REFERENCES `dogovora` (`iddogovora`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oplata`
--

LOCK TABLES `oplata` WRITE;
/*!40000 ALTER TABLE `oplata` DISABLE KEYS */;
/*!40000 ALTER TABLE `oplata` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pomesh`
--

DROP TABLE IF EXISTS `pomesh`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pomesh` (
  `idpomesh` int NOT NULL AUTO_INCREMENT,
  `ploshad` int DEFAULT NULL,
  `cena_mes` varchar(45) DEFAULT NULL,
  `etazh` varchar(2) DEFAULT NULL,
  `nomer_pomesh` varchar(45) DEFAULT NULL,
  `okna` tinyint NOT NULL,
  `ubornaya` tinyint NOT NULL,
  `kondei` tinyint NOT NULL,
  `idtc` int DEFAULT NULL,
  PRIMARY KEY (`idpomesh`),
  KEY `a4_idx` (`idtc`),
  CONSTRAINT `a4` FOREIGN KEY (`idtc`) REFERENCES `torgcenter` (`idtc`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pomesh`
--

LOCK TABLES `pomesh` WRITE;
/*!40000 ALTER TABLE `pomesh` DISABLE KEYS */;
INSERT INTO `pomesh` VALUES (1,25,'30000','4','100',1,1,0,2),(2,50,'62000','3','101',1,0,0,1),(3,30,'40000','2','102',0,1,1,3),(5,22,'20000','2','144',1,1,0,4);
/*!40000 ALTER TABLE `pomesh` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `torgcenter`
--

DROP TABLE IF EXISTS `torgcenter`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `torgcenter` (
  `idtc` int NOT NULL AUTO_INCREMENT,
  `adress` varchar(45) DEFAULT NULL,
  `etazhi` int DEFAULT NULL,
  `idadm` int DEFAULT NULL,
  PRIMARY KEY (`idtc`),
  KEY `a7_idx` (`idadm`),
  CONSTRAINT `a7` FOREIGN KEY (`idadm`) REFERENCES `workers` (`idworker`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `torgcenter`
--

LOCK TABLES `torgcenter` WRITE;
/*!40000 ALTER TABLE `torgcenter` DISABLE KEYS */;
INSERT INTO `torgcenter` VALUES (1,'Полярные зори 3',3,10),(2,'Видяево 10',4,10),(3,'Лунина 3',3,10),(4,'Видяево 11',4,10);
/*!40000 ALTER TABLE `torgcenter` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `workers`
--

DROP TABLE IF EXISTS `workers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `workers` (
  `idworker` int NOT NULL AUTO_INCREMENT,
  `fullname` varchar(45) DEFAULT NULL,
  `dr` date DEFAULT NULL,
  `phonenumber` varchar(11) DEFAULT NULL,
  `nomerpasporta` varchar(10) DEFAULT NULL,
  `iddolgnost` int DEFAULT NULL,
  `login` varchar(45) DEFAULT NULL,
  `password` varchar(45) DEFAULT NULL,
  `status` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`idworker`),
  KEY `a1_idx` (`iddolgnost`),
  CONSTRAINT `a1` FOREIGN KEY (`iddolgnost`) REFERENCES `dolgnosti` (`iddolgnost`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `workers`
--

LOCK TABLES `workers` WRITE;
/*!40000 ALTER TABLE `workers` DISABLE KEYS */;
INSERT INTO `workers` VALUES (10,'Анисов Никита Александрович','2000-03-12','79213647823','4717893339',1,'first','1','работает'),(11,'Хромов Андрей Петрович','2001-09-22','79967488923','4710209386',2,'second','2','работает'),(12,'Лебедев Дмитрий Александрович','2003-12-03','79900198934','4723109388',2,'thrid','3','работает'),(13,'Комаров Андрей Васильевич','2023-05-29','79922309485','4717569208',2,'four','4','работает');
/*!40000 ALTER TABLE `workers` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-06-13 13:09:42
